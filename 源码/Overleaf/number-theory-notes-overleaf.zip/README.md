# 数论基础笔记

这是基于 `AJbook` 模板整理的数论课程讲义项目。根文件是 `main.tex`，原始材料统一保存在 `sources/` 下。

## 编译

建议使用 XeLaTeX：

```bash
latexmk -pdf -pdflatex='xelatex -interaction=nonstopmode %O %S' main.tex
```

也可以在 Overleaf 中将 Compiler 设为 `XeLaTeX`，主文件设为 `main.tex`。

## 目录约定

- `tex/chapters/`: 按数学内容整理的讲义正文。
- `tex/weeks/`: 按课程周次维护的转写记录。
- `tex/frontmatter/`: 前言、整理约定和授课进度表。
- `sources/`: 原始材料，不得改写。

## 转写原则

首要目标是忠实转换，而不是重新写作。逐页、逐段、逐句处理原始材料；不得遗漏定义、定理、证明、例子、练习、计算、旁注、编号和逻辑顺序。

无法辨认或无法确认周次时，必须在源码中保留 `\todo{...}` 占位符，并写明来源文件、页码和位置。
